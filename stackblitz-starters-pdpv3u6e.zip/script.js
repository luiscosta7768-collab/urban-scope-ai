const form = document.querySelector(".project-form");
const submitButton = document.querySelector(".submit-button");

form.addEventListener("submit", async function (event) {
  event.preventDefault();

  const originalText = submitButton.textContent;

  submitButton.textContent = "Sending...";
  submitButton.disabled = true;

  const formData = new FormData(form);

  try {

    const response = await fetch("https://formspree.io/f/mrpbvqoe", {
      method: "POST",
      body: formData,
      headers: {
        Accept: "application/json"
      }
    });

    if (response.ok) {

      submitButton.textContent = "Request received ✓";
      submitButton.classList.add("success");

      form.reset();

    } else {

      submitButton.textContent = "Something went wrong — try again";
      submitButton.disabled = false;

    }

  } catch (error) {

    submitButton.textContent = "Connection error — try again";
    submitButton.disabled = false;

  }

});